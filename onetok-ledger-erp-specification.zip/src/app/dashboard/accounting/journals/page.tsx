import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { journals, chartOfAccounts, journalLines, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Plus, Filter, Download } from "lucide-react";
import Link from "next/link";

async function getJournals(tenantId: string) {
  const journalList = await db
    .select({
      id: journals.id,
      journalNumber: journals.journalNumber,
      date: journals.date,
      description: journals.description,
      reference: journals.reference,
      status: journals.status,
      totalDebit: journals.totalDebit,
      totalCredit: journals.totalCredit,
      createdAt: journals.createdAt,
    })
    .from(journals)
    .where(eq(journals.tenantId, tenantId))
    .orderBy(desc(journals.date), desc(journals.createdAt))
    .limit(100);

  return journalList;
}

export default async function JournalsPage() {
  const session = await getSession();
  if (!session) {
    redirect("/login");
  }

  const journalList = await getJournals(session.tenant.id);

  const totals = journalList.reduce(
    (acc, j) => ({
      posted: acc.posted + (j.status === "posted" ? 1 : 0),
      draft: acc.draft + (j.status === "draft" ? 1 : 0),
      totalValue:
        acc.totalValue +
        (j.status === "posted" ? parseFloat(j.totalDebit || "0") : 0),
    }),
    { posted: 0, draft: 0, totalValue: 0 }
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Journal Entries</h1>
          <p className="text-slate-500">
            View and manage accounting journal entries
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Link href="/dashboard/accounting/journals/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Journal
            </Button>
          </Link>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm font-medium text-slate-500">Total Journals</p>
            <p className="text-2xl font-bold">{journalList.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm font-medium text-slate-500">Posted Value</p>
            <p className="text-2xl font-bold">
              {formatCurrency(totals.totalValue, session.tenant.currency || "PGK")}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm font-medium text-slate-500">Draft Entries</p>
            <p className="text-2xl font-bold">{totals.draft}</p>
          </CardContent>
        </Card>
      </div>

      {/* Journals Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Journals</CardTitle>
          <CardDescription>
            {journalList.length} journal entries
          </CardDescription>
        </CardHeader>
        <CardContent>
          {journalList.length === 0 ? (
            <div className="py-12 text-center text-slate-500">
              <p>No journal entries yet</p>
              <Link href="/dashboard/accounting/journals/new">
                <Button variant="link">Create your first journal entry</Button>
              </Link>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Number</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead className="text-right">Debit</TableHead>
                  <TableHead className="text-right">Credit</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {journalList.map((journal) => (
                  <TableRow key={journal.id}>
                    <TableCell className="font-mono font-medium">
                      <Link
                        href={`/dashboard/accounting/journals/${journal.id}`}
                        className="hover:text-emerald-600 hover:underline"
                      >
                        {journal.journalNumber}
                      </Link>
                    </TableCell>
                    <TableCell>
                      {journal.date ? formatDate(journal.date) : "-"}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {journal.description || "-"}
                    </TableCell>
                    <TableCell>{journal.reference || "-"}</TableCell>
                    <TableCell className="text-right font-mono">
                      {formatCurrency(
                        journal.totalDebit || "0",
                        session.tenant.currency || "PGK"
                      )}
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {formatCurrency(
                        journal.totalCredit || "0",
                        session.tenant.currency || "PGK"
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          journal.status === "posted"
                            ? "success"
                            : journal.status === "draft"
                            ? "secondary"
                            : journal.status === "reversed"
                            ? "warning"
                            : "destructive"
                        }
                      >
                        {journal.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
