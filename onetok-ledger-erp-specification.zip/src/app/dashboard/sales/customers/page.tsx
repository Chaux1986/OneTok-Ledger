import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { customers, invoices } from "@/db/schema";
import { eq, asc, sql } from "drizzle-orm";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatCurrency } from "@/lib/utils";
import { Plus, Download, Users, Mail, Phone } from "lucide-react";
import Link from "next/link";

async function getCustomers(tenantId: string) {
  return db
    .select()
    .from(customers)
    .where(eq(customers.tenantId, tenantId))
    .orderBy(asc(customers.name));
}

export default async function CustomersPage() {
  const session = await getSession();
  if (!session) {
    redirect("/login");
  }

  const customerList = await getCustomers(session.tenant.id);

  const totalCreditLimit = customerList.reduce(
    (sum, c) => sum + parseFloat(c.creditLimit || "0"),
    0
  );
  const activeCount = customerList.filter((c) => c.isActive).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Customers</h1>
          <p className="text-slate-500">
            Manage your customer database and accounts receivable
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Link href="/dashboard/sales/customers/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Customer
            </Button>
          </Link>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm font-medium text-slate-500">Total Customers</p>
            <p className="text-2xl font-bold">{customerList.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm font-medium text-slate-500">Active Customers</p>
            <p className="text-2xl font-bold">{activeCount}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm font-medium text-slate-500">Total Credit Limit</p>
            <p className="text-2xl font-bold">
              {formatCurrency(totalCreditLimit, session.tenant.currency || "PGK")}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Customers Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Customers</CardTitle>
          <CardDescription>
            {customerList.length} customers in your database
          </CardDescription>
        </CardHeader>
        <CardContent>
          {customerList.length === 0 ? (
            <div className="py-12 text-center text-slate-500">
              <Users className="mx-auto h-12 w-12 text-slate-300" />
              <p className="mt-4">No customers yet</p>
              <Link href="/dashboard/sales/customers/new">
                <Button variant="link">Add your first customer</Button>
              </Link>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Tax Number</TableHead>
                  <TableHead>Payment Terms</TableHead>
                  <TableHead className="text-right">Credit Limit</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customerList.map((customer) => (
                  <TableRow key={customer.id}>
                    <TableCell className="font-mono font-medium">
                      <Link
                        href={`/dashboard/sales/customers/${customer.id}`}
                        className="hover:text-emerald-600 hover:underline"
                      >
                        {customer.code}
                      </Link>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{customer.name}</p>
                        {customer.tradingName && (
                          <p className="text-sm text-slate-500">
                            t/a {customer.tradingName}
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {customer.email && (
                          <div className="flex items-center gap-1 text-sm text-slate-600">
                            <Mail className="h-3 w-3" />
                            {customer.email}
                          </div>
                        )}
                        {customer.phone && (
                          <div className="flex items-center gap-1 text-sm text-slate-600">
                            <Phone className="h-3 w-3" />
                            {customer.phone}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{customer.taxNumber || "-"}</TableCell>
                    <TableCell>{customer.paymentTermDays} days</TableCell>
                    <TableCell className="text-right font-mono">
                      {formatCurrency(
                        customer.creditLimit || "0",
                        session.tenant.currency || "PGK"
                      )}
                    </TableCell>
                    <TableCell>
                      {customer.isActive ? (
                        <Badge variant="success">Active</Badge>
                      ) : (
                        <Badge variant="secondary">Inactive</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
