import { NextResponse } from "next/server";
import { db } from "@/db";
import { chartOfAccounts } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

// PNG-compliant default chart of accounts
const defaultAccounts = [
  // Assets
  { code: "1000", name: "Cash on Hand", type: "asset", subtype: "current_asset" },
  { code: "1010", name: "Petty Cash", type: "asset", subtype: "current_asset" },
  { code: "1100", name: "Bank - Operating Account", type: "asset", subtype: "current_asset" },
  { code: "1110", name: "Bank - Savings Account", type: "asset", subtype: "current_asset" },
  { code: "1200", name: "Accounts Receivable", type: "asset", subtype: "current_asset" },
  { code: "1210", name: "Allowance for Doubtful Debts", type: "asset", subtype: "current_asset" },
  { code: "1300", name: "Inventory", type: "asset", subtype: "current_asset" },
  { code: "1400", name: "Prepaid Expenses", type: "asset", subtype: "current_asset" },
  { code: "1410", name: "Prepaid Insurance", type: "asset", subtype: "current_asset" },
  { code: "1500", name: "GST Receivable", type: "asset", subtype: "current_asset" },
  { code: "1600", name: "Land", type: "asset", subtype: "fixed_asset" },
  { code: "1610", name: "Buildings", type: "asset", subtype: "fixed_asset" },
  { code: "1615", name: "Accumulated Depreciation - Buildings", type: "asset", subtype: "fixed_asset" },
  { code: "1620", name: "Motor Vehicles", type: "asset", subtype: "fixed_asset" },
  { code: "1625", name: "Accumulated Depreciation - Vehicles", type: "asset", subtype: "fixed_asset" },
  { code: "1630", name: "Office Equipment", type: "asset", subtype: "fixed_asset" },
  { code: "1635", name: "Accumulated Depreciation - Equipment", type: "asset", subtype: "fixed_asset" },
  { code: "1640", name: "Furniture & Fixtures", type: "asset", subtype: "fixed_asset" },
  { code: "1645", name: "Accumulated Depreciation - Furniture", type: "asset", subtype: "fixed_asset" },
  { code: "1700", name: "Intangible Assets", type: "asset", subtype: "fixed_asset" },

  // Liabilities
  { code: "2000", name: "Accounts Payable", type: "liability", subtype: "current_liability" },
  { code: "2100", name: "Accrued Expenses", type: "liability", subtype: "current_liability" },
  { code: "2110", name: "Accrued Wages", type: "liability", subtype: "current_liability" },
  { code: "2200", name: "GST Payable", type: "liability", subtype: "current_liability" },
  { code: "2210", name: "GST Collected", type: "liability", subtype: "current_liability" },
  { code: "2300", name: "PAYE Tax Payable", type: "liability", subtype: "current_liability" },
  { code: "2310", name: "Salary & Wages Tax Payable", type: "liability", subtype: "current_liability" },
  { code: "2400", name: "Superannuation Payable - Nasfund", type: "liability", subtype: "current_liability" },
  { code: "2410", name: "Superannuation Payable - Nambawan Super", type: "liability", subtype: "current_liability" },
  { code: "2500", name: "Annual Leave Payable", type: "liability", subtype: "current_liability" },
  { code: "2510", name: "Long Service Leave Payable", type: "liability", subtype: "current_liability" },
  { code: "2600", name: "Short Term Loan", type: "liability", subtype: "current_liability" },
  { code: "2700", name: "Bank Loan", type: "liability", subtype: "long_term_liability" },
  { code: "2800", name: "Hire Purchase Liability", type: "liability", subtype: "long_term_liability" },

  // Equity
  { code: "3000", name: "Share Capital", type: "equity", subtype: "equity" },
  { code: "3100", name: "Retained Earnings", type: "equity", subtype: "equity" },
  { code: "3200", name: "Current Year Earnings", type: "equity", subtype: "equity" },
  { code: "3300", name: "Drawings", type: "equity", subtype: "equity" },
  { code: "3400", name: "Owner's Contributions", type: "equity", subtype: "equity" },

  // Revenue
  { code: "4000", name: "Sales Revenue", type: "revenue", subtype: "operating_revenue" },
  { code: "4010", name: "Service Revenue", type: "revenue", subtype: "operating_revenue" },
  { code: "4020", name: "Contract Revenue", type: "revenue", subtype: "operating_revenue" },
  { code: "4100", name: "Interest Income", type: "revenue", subtype: "other_revenue" },
  { code: "4200", name: "Rental Income", type: "revenue", subtype: "other_revenue" },
  { code: "4300", name: "Gain on Asset Disposal", type: "revenue", subtype: "other_revenue" },
  { code: "4900", name: "Other Income", type: "revenue", subtype: "other_revenue" },

  // Cost of Sales
  { code: "5000", name: "Cost of Goods Sold", type: "expense", subtype: "cost_of_sales" },
  { code: "5100", name: "Direct Labour", type: "expense", subtype: "cost_of_sales" },
  { code: "5200", name: "Direct Materials", type: "expense", subtype: "cost_of_sales" },
  { code: "5300", name: "Subcontractor Costs", type: "expense", subtype: "cost_of_sales" },
  { code: "5400", name: "Freight & Delivery", type: "expense", subtype: "cost_of_sales" },

  // Operating Expenses
  { code: "6000", name: "Salaries & Wages", type: "expense", subtype: "operating_expense" },
  { code: "6010", name: "Superannuation Expense", type: "expense", subtype: "operating_expense" },
  { code: "6020", name: "Staff Training", type: "expense", subtype: "operating_expense" },
  { code: "6030", name: "Staff Welfare", type: "expense", subtype: "operating_expense" },
  { code: "6100", name: "Rent Expense", type: "expense", subtype: "operating_expense" },
  { code: "6110", name: "Utilities - Electricity", type: "expense", subtype: "operating_expense" },
  { code: "6120", name: "Utilities - Water", type: "expense", subtype: "operating_expense" },
  { code: "6200", name: "Telephone & Internet", type: "expense", subtype: "operating_expense" },
  { code: "6210", name: "Postage & Courier", type: "expense", subtype: "operating_expense" },
  { code: "6300", name: "Motor Vehicle Expenses", type: "expense", subtype: "operating_expense" },
  { code: "6310", name: "Fuel & Oil", type: "expense", subtype: "operating_expense" },
  { code: "6320", name: "Vehicle Repairs & Maintenance", type: "expense", subtype: "operating_expense" },
  { code: "6400", name: "Office Supplies", type: "expense", subtype: "operating_expense" },
  { code: "6410", name: "Printing & Stationery", type: "expense", subtype: "operating_expense" },
  { code: "6500", name: "Insurance Expense", type: "expense", subtype: "operating_expense" },
  { code: "6600", name: "Bank Charges", type: "expense", subtype: "operating_expense" },
  { code: "6610", name: "Interest Expense", type: "expense", subtype: "operating_expense" },
  { code: "6700", name: "Accounting & Audit Fees", type: "expense", subtype: "operating_expense" },
  { code: "6710", name: "Legal Fees", type: "expense", subtype: "operating_expense" },
  { code: "6720", name: "Consulting Fees", type: "expense", subtype: "operating_expense" },
  { code: "6800", name: "Depreciation Expense", type: "expense", subtype: "operating_expense" },
  { code: "6810", name: "Amortization Expense", type: "expense", subtype: "operating_expense" },
  { code: "6900", name: "Bad Debts Expense", type: "expense", subtype: "operating_expense" },
  { code: "6910", name: "Donations", type: "expense", subtype: "other_expense" },
  { code: "6920", name: "Fines & Penalties", type: "expense", subtype: "other_expense" },
  { code: "6999", name: "Miscellaneous Expenses", type: "expense", subtype: "other_expense" },
];

export async function POST() {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!["owner", "admin"].includes(session.user.role)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // Check if accounts already exist
    const existingAccounts = await db
      .select()
      .from(chartOfAccounts)
      .where(eq(chartOfAccounts.tenantId, session.tenant.id))
      .limit(1);

    if (existingAccounts.length > 0) {
      return NextResponse.json(
        { error: "Chart of accounts already exists" },
        { status: 400 }
      );
    }

    // Insert all default accounts
    const accounts = await db
      .insert(chartOfAccounts)
      .values(
        defaultAccounts.map((acc) => ({
          tenantId: session.tenant.id,
          code: acc.code,
          name: acc.name,
          accountType: acc.type as "asset" | "liability" | "equity" | "revenue" | "expense",
          accountSubtype: acc.subtype as
            | "current_asset"
            | "fixed_asset"
            | "current_liability"
            | "long_term_liability"
            | "equity"
            | "operating_revenue"
            | "other_revenue"
            | "operating_expense"
            | "other_expense"
            | "cost_of_sales",
          isSystemAccount: true,
        }))
      )
      .returning();

    return NextResponse.json({
      success: true,
      message: `Created ${accounts.length} accounts`,
      count: accounts.length,
    });
  } catch (error) {
    console.error("Error seeding accounts:", error);
    return NextResponse.json(
      { error: "Failed to seed accounts" },
      { status: 500 }
    );
  }
}
