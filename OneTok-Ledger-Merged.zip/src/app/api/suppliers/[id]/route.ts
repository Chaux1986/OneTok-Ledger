import { db } from "@/db";
import { suppliers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(suppliers)
    .set({
      name: body.name,
      contactPerson: body.contactPerson || null,
      email: body.email || null,
      phone: body.phone || null,
      address: body.address || null,
      taxId: body.taxId || null,
      bankAccount: body.bankAccount || null,
      bankName: body.bankName || null,
      notes: body.notes || null,
      isActive: body.isActive ?? true,
      updatedAt: new Date(),
    })
    .where(eq(suppliers.id, id))
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await db.delete(suppliers).where(eq(suppliers.id, id));
  return NextResponse.json({ success: true });
}
