import { db } from "@/db";
import { suppliers } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  const data = await db.select().from(suppliers).orderBy(desc(suppliers.createdAt));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const [row] = await db
    .insert(suppliers)
    .values({
      name: body.name,
      contactPerson: body.contactPerson || null,
      email: body.email || null,
      phone: body.phone || null,
      address: body.address || null,
      taxId: body.taxId || null,
      bankAccount: body.bankAccount || null,
      bankName: body.bankName || null,
      notes: body.notes || null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
